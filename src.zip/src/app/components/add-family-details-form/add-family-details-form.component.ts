import { Component } from '@angular/core';

@Component({
  selector: 'app-add-family-details-form',
  templateUrl: './add-family-details-form.component.html',
  styleUrl: './add-family-details-form.component.css'
})
export class AddFamilyDetailsFormComponent {

}
