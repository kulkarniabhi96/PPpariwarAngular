import { Component } from '@angular/core';

@Component({
  selector: 'app-darshan-registration-form',
  templateUrl: './darshan-registration-form.component.html',
  styleUrl: './darshan-registration-form.component.css'
})
export class DarshanRegistrationFormComponent {

}
