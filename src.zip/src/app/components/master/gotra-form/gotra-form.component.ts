import { Component } from '@angular/core';

@Component({
  selector: 'app-gotra-form',
  templateUrl: './gotra-form.component.html',
  styleUrl: './gotra-form.component.css'
})
export class GotraFormComponent {

}
