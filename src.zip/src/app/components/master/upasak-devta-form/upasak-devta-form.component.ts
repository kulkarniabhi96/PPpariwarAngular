import { Component } from '@angular/core';

@Component({
  selector: 'app-upasak-devta-form',
  templateUrl: './upasak-devta-form.component.html',
  styleUrl: './upasak-devta-form.component.css'
})
export class UpasakDevtaFormComponent {

}
